Run the http server from the assignment folder and then in the browser
browse the following url http://localhost:8080/load_externalfile.html