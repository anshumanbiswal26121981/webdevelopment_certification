export interface Employee {
    id: number;
    first_name: string;
    last_name: string;
    dept: string;
    city: string;
    email: string;
    showEdit: boolean;
    showUpdate: boolean;
  }